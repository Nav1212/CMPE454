/* shadeMode.h
 */


#ifndef SHADEMODE_H
#define SHADEMODE_H

typedef enum { NONE, FLAT, SMOOTH } shadeModeType;

#endif
